(function ($, $document) {
    "use strict";

    var FIRST_DROPDOWN = "./palette", SECOND_DROPDOWN = "./color";
    var TEXT_SHADOW = "text-shadow:" +
        "1px 0 darkgrey, 0 1px darkgrey," +
        "-1px 0 whitesmoke, 0 -1px whitesmoke;";

    function adjustLayoutHeight() {
        $(".coral-FixedColumn-column").css("height", "20rem");
    }

    function getColorPreviewHtml(color) {
        return " <i class=\"coral-Icon--sizeXS coral-Icon coral-Icon--circle\"" +
            "style=\"" + TEXT_SHADOW + "color: #" + color + ";\"></i> ";
    }

    function populateColorOptions(paletteColors, selectedPalette){
        // Initializing color drop down field
        var colorSelect = new CUI.Select({
            element: $("[name='" + SECOND_DROPDOWN +"']").closest(".coral-Select")
        });
        var colorField = $("[name='" + SECOND_DROPDOWN + "']");

        // Empty list
        colorSelect._selectList.children().not("[role='option']").remove();
        colorField.siblings(".coral-SelectList").find('li').remove().end();

        _.each(paletteColors, function(color, palette) {
            if(color.palette !== selectedPalette) return;

            // Add options to color field with null html so they are hidden
            $("<option>")
                .appendTo(colorField[0])
                .val(palette)
                .html(null);

            // Add options with color preview to select list
            $("<li>").appendTo(colorField.siblings(".coral-SelectList")[0])
                .attr({
                    "class": "coral-SelectList-item coral-SelectList-item--option",
                    "data-value": color.color,
                    "role": "option"
                })
                .html(getColorPreviewHtml(color.color) + "&nbsp;" + color.color);
        });
    }

    $document.on("dialog-ready", function() {
        var paletteColors = {};
        var selectedPalette;

        // Get the languages list from the source
        $.getJSON("/libs/wcm/core/resources/languages.2.json").done(function(data){
            paletteColors = data;

            // Apply color preview to palette dropdown field
            var paletteItems = $("[name='" + FIRST_DROPDOWN + "']")
                .siblings(".coral-SelectList").children('li');

            console.log(paletteItems)

            _.each(paletteItems, function(paletteNode) {
                selectedPalette = paletteNode.innerHTML;
                var newInnerHTML = "";

                _.each(paletteColors, function(color) {
                    if(color.palette !== selectedPalette) return;
                    newInnerHTML += getColorPreviewHtml(color.color);
                });

                paletteNode.innerHTML = newInnerHTML + paletteNode.innerHTML;
            });
        });

        adjustLayoutHeight();

        // Getting reference of palette drop down field
        var paletteSelect =
            $("[name='" + FIRST_DROPDOWN +"']").closest(".coral-Select");

        // Listener on palette select for dynamically filling the colors
        paletteSelect.on('selected.select', function(event) {
            populateColorOptions(paletteColors, event.selected);
        });
    });
})($, $(document));