(function ($, $document) {
    "use strict";

    var PRODUCT = "./product", ARTICLE = "./article";

    function adjustLayoutHeight(){
        $(".coral-FixedColumn-column").css("height", "20rem");
    }

    $document.on("dialog-ready", function() {
        adjustLayoutHeight();

        // Getting reference of product drop down field
        var product = $("[name='" + PRODUCT +"']").closest(".coral-Select")

        // Initializing article drop down field
        var article = new CUI.Select({
            element: $("[name='" + ARTICLE +"']").closest(".coral-Select")
        });

        if(_.isEmpty(article) || _.isEmpty(product)){
            return;
        }

        var articleList = {};

        article._selectList.children().not("[role='option']").remove();

        function fillArticles(selectedLang, selectedCountry){
            var x = $("[name='./article']").closest(".coral-Select").find('option').remove().end();
            _.each(articleList, function(value) {

                var test2 = $("[name='./article']")[0];

                $("<option>").appendTo(test2).val(value.url).html(value.headline);
            });

            article = new CUI.Select({
                element: $("[name='" + ARTICLE +"']").closest(".coral-Select")
            });

            if(!_.isEmpty(selectedCountry)){
                article.setValue(selectedCountry);
            }

            //article.find('option:eq(0)').prop('selected', true);

        }

        //listener on product select for dynamically filling the countries on product select
        product.on('selected.select', function(event){
            console.log(event);
            getArticles(event.selected);
        });

        function getArticles(selectedLang){
            //var url = "http://aem-docker-qa11.aws-preprod.telegraph.co.uk:4503/bin/custom/fs/articles?product="
            var url = "http://localhost:4502/apps/fs-core/components/datasource/"
            //var fullURL = url + selectedLang";
            var fullURL = url + selectedLang + ".json";

            $.getJSON(fullURL).done(function(data){
                articleList = data.items;

                //console.log(data);

                fillArticles(product.val(), data.items);
            });
        }

        var selectedProduct = $("[name='./product']").find(":selected").text();
        if (selectedProduct) {
            getArticles(selectedProduct);
        }

    });
})($, $(document));