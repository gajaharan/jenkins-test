use(function () {
    response.setHeader("useEjs", "true");
});